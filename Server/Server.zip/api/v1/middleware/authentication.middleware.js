module.exports.requiresLogin = async (req, res, next) => {};

module.exports.requiresLogout = async (req, res, next) => {};
